﻿using System.ComponentModel.DataAnnotations;

namespace SessionCookies.Models
{
    public class User
    {
        [Display(Name = "Kullanıcı Adı")]

        [MinLength(3,ErrorMessage = "Kullanıcı Adı en az 3 karakter olamlı")]
        public string Username { get; set; }

        [DataType(DataType.Password)]  //kullanıcı şifresi * şeklinde görünmesi için
        [Display(Name = "Parola")]
        public string UserPassword { get; set; }




        public string UserColor { get; set; }





    }
}
