﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using SessionCookies.Models;
using System.Text.Json.Serialization;

using Newtonsoft.Json;

namespace SessionCookies.Controllers
{


    public class UserController : Controller
    {
        static List<User> users = new List<User>()
    {
        new User(){Username ="gunduz", UserPassword = "123", UserColor = "red"},
        new User(){Username ="ahmet",UserPassword = "asd", UserColor = "green"},
        new User(){Username ="mehmet", UserPassword = "qwe", UserColor = "blue"}

    };



        public IActionResult LoginUser(User usr)
        {
            foreach (var u in users)
            {
                if (u.Username == usr.Username && u.UserPassword == usr.UserPassword)
                {
                    HttpContext.Session.SetString("SessionUser", u.Username);//sessiona sadece string kaydedilir başka bir şey edilemez
                    var ckOpt = new CookieOptions
                    {
                        Expires = DateTime.Now.AddMinutes(10)
                    };
                    HttpContext.Response.Cookies.Append("CookiesColor", u.UserColor, ckOpt);
                    return RedirectToAction("YetkiliUserSayfasi");

                }
            }
            TempData["txtInfo"] = "Kullanıcı adı ya da Parola hatalı";
            return RedirectToAction("Index");


        }

        public IActionResult YetkiliUserSayfasi()
        {

            if (HttpContext.Session.GetString("SessionUser") is null)
            {
                TempData["txtInfo"] = "Login olmadan bu sayfaya giremezsiniz";
                return RedirectToAction("Index");
            }
            return View();

        }


        public IActionResult UsrLogout()
        {
            HttpContext.Session.Clear();
            TempData["txtInfo"] = "Oturum güvenli bir şekilde sonlandı";
            return RedirectToAction("Index");
        }


        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("SessionUser") is not null)
            {
                TempData["txtInfo"] = "kULLANICI ZATEN OTURUM AÇMIŞ.Yetkili sayfaya yönlendirildi";
                return RedirectToAction("YetkiliUserSayfasi");
            }


            return View();
        }

        public IActionResult SetSessionUsrObject()
        {
            User usr = new User();

            usr.Username = "Hasan";
            usr.UserPassword = "456";
            usr.UserColor = "skyblue";

            string sObj = JsonConvert.SerializeObject(usr);
            HttpContext.Session.SetString("SessionUsrObject",sObj);

            return RedirectToAction("SetSessionUsrObject"); // SetSessionUsrObject yönlendir

        }


    }

}
