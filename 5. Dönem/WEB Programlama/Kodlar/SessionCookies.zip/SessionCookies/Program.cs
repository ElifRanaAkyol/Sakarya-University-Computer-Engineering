var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();


//Session ekleme        sadece k�t�phaneyi ekliyoz
builder.Services.AddSession(
    
    options =>
    {
        options.IdleTimeout = TimeSpan.FromMinutes(30); //Kullan�c� hi�bir i�lem yapmadan sayfan�n ne kadar a��k kalaca��na karar veriyoz. (30dk)


        //Cookie Yap�land�rmas� 
        options.Cookie.HttpOnly = true; //bu �u demek : bu uyg'n�n �erez dosyalar� ya da cookieleri yaln�zca sunucu taraf�ndan okunup i�lem yap�labilir.
        options.Cookie.IsEssential = true; // Avrupa birli�inde 'GDPR' diye bir uygulama var.Burada kullan�c�dan bu kanun nezlinde kullan�c� hi�bir �eyin
                                           // al�nmas�na  izin vermemesine ra�men belli ba�l� verilerin  al�nmas�d�r.
            


    }





);



var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession(); //yukar�daki k�t�phaneyi kullanmak i�in ekledik

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=User}/{action=Index}/{id?}");

app.Run();
