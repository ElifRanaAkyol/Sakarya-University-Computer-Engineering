#include "TreeNode.hpp"

// TreeNode sınıfının varsayılan kurucusu
TreeNode::TreeNode(): data('\0'), left(NULL), right(NULL) {}

// TreeNode sınıfının parametreli kurucusu
TreeNode::TreeNode(char data): data(data), left(NULL), right(NULL) {}

// TreeNode sınıfının yıkıcısı
TreeNode::~TreeNode() {}

// Ağacın toplam puanını recursive olarak hesaplar
int TreeNode::calculateTotalScoreRecursive() {
    int totalScore = 0;

    // Bu düğümün puanını hesapla
    totalScore += calculateTotalScore();

    // Sol alt ağacı dola
    if (left) {
        totalScore += left->calculateTotalScoreRecursive();
    }

    // Sağ alt ağacı dola
    if (right) {
        totalScore += right->calculateTotalScoreRecursive();
    }

    return totalScore;
}

// Bu düğümün kendi puanını hesaplar
int TreeNode::calculateTotalScore() {
    int totalScore = 0;

    // Eğer sol düğüm varsa, ASCII değerini 2 ile çarp ve topla
    if (left) {
        totalScore += 2 * static_cast<int>(left->data);
    }

    // Eğer sağ düğüm varsa, ASCII değerini topla
    if (right) {
        totalScore += static_cast<int>(right->data);
    }

    return totalScore;
}