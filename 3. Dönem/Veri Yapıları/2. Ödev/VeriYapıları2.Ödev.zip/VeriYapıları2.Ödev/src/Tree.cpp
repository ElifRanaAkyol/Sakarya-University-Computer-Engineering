#include "Tree.hpp"
#include "ListNode.hpp"

// Tree sınıfının kurucusu
Tree::Tree() {
    root = NULL;
    fillMissingFlag = 1;
}

// Tree sınıfının yıkıcısı
Tree::~Tree() {
    deleteTree(root);
}

// Ağacı silmek için recursive fonksiyon
void Tree::deleteTree(TreeNode* node) {
    if (node) {
        deleteTree(node->left);
        deleteTree(node->right);
        delete node;
    }
}

// Ağaca yeni bir düğüm eklemek için recursive fonksiyon
TreeNode *Tree::insert(TreeNode *node, char data) {
    if (node == NULL) {
        return new TreeNode(data);
    }
    if (data < node->data) {
        node->left = insert(node->left, data);
    } else if (data > node->data) {
        node->right = insert(node->right, data);
    }
    return node;
}

//Ekleme fonksiyonu
void    Tree::insert(char data) {
    root = insert(root, data);
}

// Ağacın derinliğini hesapla
int getTreeDepth(TreeNode* root) {
    if (!root) return 0;
    return 1 + std::max(getTreeDepth(root->left), getTreeDepth(root->right));
}

// Belirli bir seviyedeki düğümleri toplar
void collectLevelNodes(TreeNode* root, int level, ListNode*& head) {
    if (!root) return;

    if (level == 1) {
        ListNode *newNode = new ListNode(root->data ? string(1, root->data) : "");
        if (!head) {
            head = newNode;
        } else {
            ListNode* current = head;
            while (current->next) {current = current->next;}
            current->next = newNode;
        }
    } else if (level > 1) {
        collectLevelNodes(root->left, level - 1, head);
        collectLevelNodes(root->right, level - 1, head);
    }
}

// Belirli bir seviyedeki düğümleri yazdırır
void printLevelNodes(ListNode* head, int spacing, int offset, int level) {
    ListNode* current = head->next;
    if (!head->value.empty() && head->value.at(0) != '\0') {
        cout << string(spacing, ' ') << head->value;
    } else {
        cout << string(spacing, ' ') << ' ';
    }
    while (current) {
        if (!current->value.empty() && current->value.at(0) != '\0') {
            cout << string(offset, ' ') << current->value;
        } else {
            cout << string(offset, ' ') << ' ';
        }
        current = current->next;
    }
    cout << endl;
}

// Düğümler arasındaki bağlantıları yazdırır
void printLevelConnections(ListNode* head, int spacing, int offset) {
    ListNode* current = head;
    cout << string(spacing, ' ');
    while (current) {
        
        cout << string(offset, '-') << string(offset+2, ' ');
        current = current->next;
    }
    cout << endl;
}

// Eksik düğümleri doldurur 
void fillMissingNodes(TreeNode* root, int depth, int currentDepth) {
    if (!root) return;
    if (currentDepth != depth) {
        if (!root->left) root->left = new TreeNode('\0');
        if (!root->right) root->right = new TreeNode('\0');
    }
    if (currentDepth < depth ) {
        fillMissingNodes(root->left, depth, currentDepth + 1);
        fillMissingNodes(root->right, depth, currentDepth + 1);
    }
}

// Ağacı yazdırır
void Tree::printTree() {
    int depth = getTreeDepth(root);
    
    if (this->fillMissingFlag) {
        fillMissingNodes(root, depth, 1); // Eksik düğümleri doldur
        this->fillMissingFlag = 0;
    }

    for (int i = 1; i <= depth; i++) {
        ListNode* levelNodes = nullptr;

        collectLevelNodes(root, i, levelNodes); // Belirli seviyedeki düğümleri topla

        int spacing = 1 << (depth - i);
        int offset = spacing * 2;

        printLevelNodes(levelNodes, spacing - 1, offset-1, depth - i); // Düğümleri yazdır

        if (i < depth) {
            printLevelConnections(levelNodes, (1 << (depth-i -1)), (1 << (depth-i)) - 1); // Bağlantıları yazdır
        }

        while (levelNodes) {
            ListNode* temp = levelNodes;
            levelNodes = levelNodes->next;
            delete temp;
        }
    }
}

// Ağacı aynalar (sol ve sağ alt ağaçları yer değiştirir)
void Tree::mirrorTree(TreeNode* root) {
    if (root == nullptr) {
        return;
    }
    TreeNode* temp = root->left;
    root->left = root->right;
    root->right = temp;
    mirrorTree(root->left);
    mirrorTree(root->right);
}
