#include "../include/TableNode.hpp"

// TableNode sınıfının varsayılan kurucusu
TableNode::TableNode() {
    this->point = 0;
    this->adress = 0;
    this->treeStr = "";
    this->next = NULL;
}

// TableNode sınıfının varsayılan kurucusu
TableNode::TableNode(int point, string treeStr, TableNode *next) {
    this->point = point;
    this->adress = 0;
    this->treeStr = treeStr;
    this->next = next;

    // Karakter dizisindeki her alfanümerik karakteri ağaca ekle
    for (int i = 0; i < (int)(treeStr.length()); i++) {
        if (isalnum(treeStr.at(i))) {
            this->tree.insert(treeStr.at(i));
        }
    }
}

// TableNode sınıfının yıkıcısı 
TableNode::~TableNode() {}

// Atama operatörünün aşırı yüklenmesi
TableNode &TableNode::operator=(const TableNode &other) {
    this->point = other.point;
    this->adress = other.adress;
    this->treeStr = other.treeStr;
    this->next = other.next;
    return *this;
}
