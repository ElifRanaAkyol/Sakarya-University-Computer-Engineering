#include "Table.hpp"

// Table sınıfının kurucusu.
Table::Table() {
    this->head = NULL;
    tableSlideCount = 0;
    tableSwipeCount = 0;
    flagStop = 0;
}

// Table sınıfının yıkıcısı. Bağlı listedeki düğümleri serbest bırakır.
Table::~Table() {
    TableNode *current = head;
    while (current) {
        TableNode *next = current->next;
        delete current;
        current = next;
    }
}

// Dosyadan veri okuyarak bağlı liste oluşturur
void Table::readFile(string &filename) {
    ifstream    file(filename);

    if (!file.is_open()) {
        cerr << "File is not opened. Pls check the arguement.\n";
        exit(1);
    }
    int flag = 1;
    string line;
    this->head = NULL;
    TableNode *current = new TableNode();

    while (getline(file, line)) {
        if (!isalnum(line.at(line.length()-1))) {
            line.at(line.length()-1) = '\0';
        }
        if (flag) {
            flag = 0;
            this->head = new TableNode(0, line, NULL);
            current = this->head;
            continue;
        }
        current->next = new TableNode(0, line, NULL); // Yeni düğüm oluştur ve listeye bağla

        current = current->next;
    }
    file.close();
}

// Belirtilen düğümdeki değerleri yazdırı
void Table::printValue(TableNode *firstNode) {
    TableNode *curr = firstNode;
    printLine(topLine);
    for (int i = 0; curr != NULL && i < tableNodeWidth; curr = curr->next, i++) {
        if (curr == nullptr) {
            cerr << "Error: curr is nullptr!" << std::endl;
            return;
        }
        int currScore = static_cast<int>(curr->tree.root->data) + curr->tree.root->calculateTotalScoreRecursive();
        stringstream ss;
        ss << currScore;
        cout << '|' << setw(tableNodeWidth-1) << right << ss.str();
        cout << "| " << flush;
        ss = stringstream();
    }
    cout << endl;
}
// Belirtilen düğüm adreslerini yazdırır
void Table::printAdress(TableNode *firstNode) {
    TableNode *curr = firstNode;
    printLine(topLine);

    if (curr == NULL || curr->tree.root->data == '\0') {
        cout << '|' << setw(tableNodeWidth - 1) << right << " ";
        cout << "| " << endl;
        return;
    }

    for (int i = 0; curr != NULL && i < tableNodeWidth; curr = curr->next, i++) {
        if (curr == nullptr) {
            cout << ' ' << setw(tableNodeWidth - 1) << right << " ";
            cout << "  ";
            return;
        }
        void *address = reinterpret_cast<void*>(curr);
        std::ostringstream oss;
        oss << address;
        std::string addressStr = oss.str();

        // Güvenli substr işlemi
        if (addressStr.length() >= tableNodeWidth - 1) {
            addressStr = addressStr.substr(addressStr.length() - (tableNodeWidth - 1), tableNodeWidth - 1);
        } else {
            addressStr = addressStr; // Çok kısa ise orijinal stringi bırak
        }

        cout << '|' << setw(tableNodeWidth - 1) << right << addressStr;
        cout << "| ";
    }
    cout << endl;
}

/*void Table::printAdress(TableNode *firstNode) {
    TableNode *curr = firstNode;
    printLine(topLine);
    if (curr == NULL || curr->tree.root->data == '\0') {
        cout << '|' << setw(tableNodeWidth-1) << right << " ";
        cout << "| " << endl;
        return;
    }
    for (int i = 0; curr != NULL && i < tableNodeWidth; curr = curr->next, i++) {
        if (curr == nullptr) {
            cout << ' ' << setw(tableNodeWidth-1) << right << " ";
            cout << "  ";
            return;
        }
        void *address = reinterpret_cast<void*>(curr);
        std::ostringstream oss;
        oss << address;
        std::string addressStr = oss.str();
        addressStr = addressStr.substr(addressStr.length() - tableNodeWidth+1, addressStr.length()-1);
        cout << '|' << setw(tableNodeWidth-1) << right << addressStr;
        cout << "| ";
    }
    cout << endl;
} */ 

// Çizgi çizerken kullanılan yardımcı fonksiyon
// Flag'e bağlı olarak üst çizgi, alt çizgi veya dikey çizgi çizilir
void Table::printLine(int flag) {
    int tableLen = tableSlideCount >= tableLenght() - (tableLenght() % tableNodeWidth)? tableLenght() % tableSlideWidth : tableSlideWidth;

    for (int i = 0; i < tableLen; i++) {
        if (i == tableSlideCount % tableSlideWidth && flag == bottomLine) {
            cout << string(tableLineWidth, '^');
        } else if (flag == pipeLine) {
            if (tableSlideCount % tableSlideWidth == i) {
                cout << string(tableLineWidth, '|');
            } else {
                cout << string(tableLineWidth, ' ');
            }
        }
        else {
            cout << string(tableLineWidth, '*');
        }
        if (i != tableLen - 1) {
            cout << ' ';
        }
    }
    cout << endl;
}

// Tabloyu ekrana yazdırır
void Table::printTable() {
    TableNode *tableFirstNode = head;
    for (int i = 0; tableFirstNode != NULL && i < tableSwipeCount; tableFirstNode = tableFirstNode->next, i++) {}

    if (tableFirstNode == NULL) {
        cerr << "Error: tableFirstNode or tableFirstNode->next is nullptr!" << std::endl;
        this->flagStop = 1;
        return;
    }

    printAdress(tableFirstNode);

    printValue(tableFirstNode);

    printAdress(tableFirstNode->next);

    printLine(bottomLine);
    printLine(pipeLine);

    TableNode *now = head;
    int i = 0; 
    while (now != NULL && i < tableSlideCount) {now = now->next; i++;}
    if (now != NULL) {
        now->tree.printTree();
    }
}

// Listenin düğümlerini yazdırır
void Table::printNodes() {
    TableNode *curr = head;
    for (; curr != NULL; curr = curr->next) {
        std::cout << "point:" << curr->point << " treeStr:" << curr->treeStr << endl;
        if (curr->next == NULL) {
            break;
        }
    }
}

// Listenin düğümlerini yazdırır
int Table::tableLenght() {
    TableNode *curr = head;
    for (int i = 0; curr != NULL; curr = curr->next) {
        i++;
        if (curr->next == NULL) {
            return i;
        }
    }
    return 0;
}

// Listenin soluna kaydırma işlemi
void Table::slideLeft() {
    if (tableSlideCount == 0) {
        return;
    }
    tableSlideCount--;
    this->calculateSwipeCount();
    if (tableSlideCount > tableLenght()) {
        tableSlideCount = tableLenght();
    }
    cout << "tableSlideCount: " << tableSlideCount << endl;
}

// Listenin sağına kaydırma işlemi
void Table::slideRight() {
    if (tableSlideCount == tableLenght()-1) {
        return;
    }
    tableSlideCount++;
    this->calculateSwipeCount();
    if (tableSlideCount > tableLenght()) {
        tableSlideCount = tableLenght();
    }
}

// Kaydırma sayısını hesaplar
void Table::calculateSwipeCount() {
    this->tableSwipeCount = (tableSlideCount/tableSlideWidth) * tableSlideWidth;
}

// Belirtilen indisteki düğümü siler
void Table::removeAt(int index) {
    int tableLen = tableLenght()-1;

    if (index >= tableLen) {
        this->slideLeft();
    }
    if (!head || index < 0) {
        cout << "Invalid index or empty list." << endl;
        return;
    }

    TableNode* current = head;

    if (index == 0) {
        head = NULL;
        delete current;
        cout << "List empty!" << endl;
        this->flagStop = 1;
        return;
    }

    TableNode* prev = nullptr;
    for (int i = 0; i < index; ++i) {
        prev = current;
        current = current->next;

        if (!current) {
            cout << "Index out of bounds." << endl;
            return;
        }
    }

    // Bağlantıyı atla ve düğümü sil
    prev->next = current->next;
    delete current;
}