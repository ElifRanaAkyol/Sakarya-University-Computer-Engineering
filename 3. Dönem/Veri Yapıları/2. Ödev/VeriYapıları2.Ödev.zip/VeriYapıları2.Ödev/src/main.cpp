#include "../include/main.hpp"

// Seçili düğümdeki ağacın düğümlerini aynalama işlemi yapar
void    mirrorTreeNodes(TableNode *head, int index) {
    TableNode *curr = head;
    for (int i = 0; curr != NULL && i < index; i++) {
        curr = curr->next;
    }
    curr->tree.mirrorTree(curr->tree.root);
}

int main() {
    string fname("agaclar.txt"); // İşlenecek dosya adı
    Table *table = new Table(); // Bağlı liste yapısı için Table nesnesi oluştur
    table->readFile(fname);  // Dosyadan veri okuyarak bağlı listeyi oluştur
    while (table->head != NULL) { // Bağlı liste boş olmadığı sürece çalış
        if (table->flagStop) {
            break;
        }
        system("cls");  // Ekranı temizle (Linux için). Windows'ta "cls" kullanılır. HOCAM İŞLETİM SİSTEMİNİZE GÖRE DEĞİŞTİRİN LÜTFEN
        table->printTable(); 
        char choice;
        cout << "\nEnter a choice (a: slide left, d: slide right, s: remove, w: mirror, q: quit): ";
        cin >> choice; // Kullanıcıdan bir işlem seçmesini ister

        switch (choice)
        {
        case 'a':
            table->slideLeft(); // Tabloyu sola kaydırma işlemi
            break;
        case 'd':
            table->slideRight(); // Tabloyu sağa kaydırma işlemi
            break;
        case 's':
            table->removeAt(table->tableSlideCount); // Seçili düğümü ve ağacını silme
            break;
        case 'w':
            mirrorTreeNodes(table->head, table->tableSlideCount); // Seçili ağacı aynalama
            break;
        case 'q':
            table->flagStop = 1; // Döngüyü sonlandırmak için çıkış flag'ini ayarla
            break;
        default:
            break;
        }
    }
    delete table; // Belleği serbest bırak
}

