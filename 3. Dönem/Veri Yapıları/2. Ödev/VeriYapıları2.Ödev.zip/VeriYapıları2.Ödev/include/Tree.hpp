#pragma once

#include <stdlib.h>
#include <iostream>
#include "TreeNode.hpp"

using namespace std;

// Tree sınıfı, ikili arama ağacı yapısını ve ilgili işlemleri yönetir.
class Tree {
public:
    int         fillMissingFlag; // Eksik düğümleri doldurma flag'i
    int         score; // Ağacın toplam puanı
    TreeNode    *root; // Ağacın kök düğümü

    Tree();
    ~Tree();
    TreeNode *insert(TreeNode *node, char data);
    void    insert(char data);

    void  printTree();

    void mirrorTree(TreeNode* root);

    void deleteTree(TreeNode* node);
};
