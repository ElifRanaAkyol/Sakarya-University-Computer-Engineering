#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include "TableNode.hpp"
#include "Table.hpp"
#include "Tree.hpp"

using namespace std;

void    mirrorTreeNodes(TableNode *head, int index);