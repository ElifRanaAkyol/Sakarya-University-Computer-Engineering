#pragma once

#include <stdlib.h>
#include <cstdint>
#include <string>
#include <ctype.h>
#include "Tree.hpp"

using namespace std;

// TableNode sınıfı, bağlı listenin düğümlerini temsil eder.
class TableNode {
public:
    int         point; // Düğümün puanı
    int         adress; // Düğümün adresi
    string      treeStr; // Düğümle ilişkili karakter dizisi
    Tree        tree; // Düğümle ilişkili ikili arama ağacı
    TableNode   *next; // Bir sonraki düğüme işaretçi

    TableNode();
    TableNode(int point, string treeStr, TableNode *next);
    ~TableNode();
    TableNode &operator=(const TableNode &other);
   
};

