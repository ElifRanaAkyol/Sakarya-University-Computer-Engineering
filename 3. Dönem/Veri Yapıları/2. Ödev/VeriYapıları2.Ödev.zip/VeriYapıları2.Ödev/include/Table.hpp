#pragma once

#include <stdlib.h>
#include <string>
#include <cmath>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <iostream>
#include "TableNode.hpp"

using namespace std;

// Sabitler
#define tableSlideWidth 10
#define tableNodeWidth 10
#define tableLineWidth 11

// Çizgi türleri
#define topLine 0
#define bottomLine 1
#define pipeLine 2

class Table {
public:
    int     tableSlideCount; // Tablo kaydırma sayacı
    int     tableSwipeCount; // Tablo görünüm değişim sayacı
    int     flagStop; // Döngüden çıkış flag'i

    TableNode *head;
    Table();
    ~Table();
    void    readFile(string &filename);

    void    printTable();
    void    printNodes();
    void    printLine(int flag);
    int     tableLenght();
    void    slideLeft();
    void    slideRight();
    void    calculateSwipeCount();
    void    printValue(TableNode *firstNode);
    void    printAdress(TableNode *firstNode);

    void    removeAt(int index);
};
