#pragma once

#include <string>

using namespace std;

// ListNode yapısı, bir bağlantılı listenin düğümlerini temsil eder.
struct ListNode {
    string value; // Düğümdek i veri
    ListNode* next; // Sonraki düğüme işaretçi

  
    ListNode(string val) : value(val), next(nullptr) {}
};