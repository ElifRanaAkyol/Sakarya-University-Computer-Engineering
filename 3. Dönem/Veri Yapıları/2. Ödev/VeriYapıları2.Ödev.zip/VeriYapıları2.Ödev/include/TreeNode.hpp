#pragma once

#include <iostream>

// TreeNode sınıfı, ikili arama ağacındaki düğümleri temsil eder.
class TreeNode {
public:
    char        data; // Düğümdeki veri (karakter)
    TreeNode    *left; // Sol alt düğüme işaretçi
    TreeNode    *right; // Sağ alt düğüme işaretçi

    TreeNode();
    TreeNode(char data);
    ~TreeNode();
    int calculateTotalScoreRecursive();
    int calculateTotalScore();
};