#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include <stdio.h>
#include <stdlib.h>

// Define a structure for the linked list node
struct Node {
    char data;
    struct Node* next;
};

// Function declarations
struct Node* newNode(char data);
void append(struct Node** head_ref, char new_data);
void deleteCharacter(struct Node** head_ref, char character, int count);
void printListToFile(FILE* file, struct Node* node);

#endif /* LINKED_LIST_H */

