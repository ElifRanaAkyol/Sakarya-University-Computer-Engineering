#ifndef FIELDS_H
#define FIELDS_H

#include <stdio.h>
#include <stdlib.h>

// Define a structure for the doubly linked list node
struct Node {
    char data;
    int index; // Index of the node
    struct Node* next;
    struct Node* prev; // Pointer to previous node
};

// Function prototypes
struct Node* newNode(char data, int index);
void addNodeAfter(struct Node* prev_node, char new_data, int index);
void insert(struct Node** head_ref, char new_data, int index);
void deleteCharacter(struct Node** head_ref, char character, int count,int *index);
void printListToFile(FILE* file, struct Node* node);
void GoToLast(struct Node* node, int* node_index);

#endif /* FIELDS_H */

