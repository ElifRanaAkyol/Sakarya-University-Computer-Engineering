#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "fields.h"


#define MAX_LINE_LENGTH 1000

// Define a structure for the doubly linked list node
struct Node {
    char data;
    int index; // Index of the node
    struct Node* next;
    struct Node* prev; // Pointer to previous node
};

// Function prototypes
struct Node* newNode(char data, int index);
void addNodeAfter(struct Node* prev_node, char new_data, int index);
void insert(struct Node** head_ref, char new_data, int index);
void deleteCharacter(struct Node** head_ref, char character, int count,int *index);
void printListToFile(FILE* file, struct Node* node);

// Function to create a new node
struct Node* newNode(char data, int index) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        fprintf(stderr, "Memory allocation failed.\n");
        exit(EXIT_FAILURE);
    }
    newNode->data = data;
    newNode->index = index;
    newNode->next = NULL;
    newNode->prev = NULL; // Initialize prev pointer to NULL
    return newNode;
}

// Function to add a new node after a given node pointer
void addNodeAfter(struct Node* prev_node, char new_data, int index) {
    if (prev_node == NULL) {
        printf("Previous node cannot be NULL.\n");
        return;
    }
    

    struct Node* new_node = newNode(new_data, index); // Create a new node
    struct Node* next_node = prev_node->next; // Store the next node

    // Update pointers of the new node
    new_node->prev = prev_node;
    new_node->next = next_node;

    // Update pointers of the previous node and the next node
    prev_node->next = new_node;
    if (next_node != NULL)
        next_node->prev = new_node;
}

// Function to insert a new node at the specified index of the doubly linked list
void insert(struct Node** head_ref, char new_data, int index) {
    struct Node* new_node = newNode(new_data, index);
    if (*head_ref == NULL) {
        *head_ref = new_node;
        return;
    }
    struct Node* current = *head_ref;
  
    while (current != NULL && current->index < index)
        current = current->next;

    // If index is greater than the index of last node
    if (current == NULL) {
        struct Node* last = *head_ref;
        while (last->next != NULL)
            last = last->next;
        last->next = new_node;
        new_node->prev = last; // Update prev pointer
    } else {
        struct Node* prev = current->prev;
        new_node->next = current;
        new_node->prev = prev;
        current->prev = new_node;
        if (prev != NULL)
            prev->next = new_node;
        else
            *head_ref = new_node;
    }
    if(new_node->next!=NULL)
    if(new_node->index==new_node->next->index)
           new_node->next->index+=1;

}

// Function to delete specified number of occurrences of a character from the doubly linked list
void deleteCharacter(struct Node** head_ref, char character, int count, int *index) {
    if (*head_ref == NULL)
        return;

    struct Node* current = *head_ref;
    int deleted = 0;

    // Traverse to the last node
    while (current->next != NULL)
        current = current->next;

    // Start traversing from the last node towards the head
    while (current != NULL && deleted < count) {
        if (current->data == character) {
            if (current == *head_ref) {
                *head_ref = current->next;
                if (*head_ref != NULL)
                    (*head_ref)->prev = NULL; // Update prev pointer of the new head
                free(current);
                current = *head_ref;
            } else {
                struct Node* prev = current->prev;
                prev->next = current->next;
                if (current->next != NULL)
                    current->next->prev = prev; // Update prev pointer of the next node
                free(current);
                current = prev->next;
            }
            deleted++;
        } else {
            current = current->prev;
        }
    }
    if(deleted==count)
      *index =  current->prev->index + 1;
}

// Function to print the doubly linked list to a file
void printListToFile(FILE* file, struct Node* node) {
    while (node != NULL) {
        fprintf(file, "%c", node->data);
        node = node->next;
    }
}
void GoToLast( struct Node* node,int * node_index) {
    while (node->next != NULL) {
        node = node->next;
       
    }
     *node_index=node->index+1;
    
}


int main(int argc, char *argv[]) {
    char *input_filename = "./in_out_files/giris.dat";
    char *output_filename = "./in_out_files/cikis.dat";

    if (argc > 1)
        input_filename = argv[1];
    if (argc > 2)
        output_filename = argv[2];




// Open the input file
    IS is = new_inputstruct(input_filename);
    if (is == NULL) {
        fprintf(stderr, "Error opening input file %s.\n", input_filename);
        // Use default input file
        fprintf(stderr, "Using default input file ./in_out_files/giris.dat .\n", input_filename);
        is = new_inputstruct("./in_out_files/giris.dat");
        if (is == NULL) {
            fprintf(stderr, "Error opening default input file %s.\n", input_filename);
            return 1;
        }
    }



    // Open the output file for writing
    FILE* outFile = fopen(output_filename, "w");
    if (outFile == NULL) {
        fprintf(stderr, "Error opening output file %s.\n", output_filename);
        return 1;
    }

    // Check output file extension
    if (strcmp(strrchr(output_filename, '.'), ".dat") != 0) {
        fprintf(stderr, "Output file extension is not .dat.\n");
        return 1;
    }

    int repetition = 0;
    int node_index = 0; // Index for nodes in the doubly linked list
  
   
    // Initialize doubly linked list head
    struct Node* head = NULL;

    // Loop through each line of the input file
    while (get_line(is) >= 0) {
        char* token = NULL;
        if ((token = strstr(is->text1, "yaz:")) != NULL) {
            token += strlen("yaz:");
            while (*token != '\0') {
                if (isalpha(*token) || *token == '\\') {
                    for (int i = 0; i < repetition; i++) {
                        if (*(token + 1) == 'n') {
                            insert(&head, '\n', node_index++);
                            continue;
                        } else if (*(token + 1) == 'b') {
                            insert(&head, ' ', node_index++);
                            continue;
                        }
                        insert(&head, *token, node_index++);
                    }
                    repetition = 0;
                } else if (isdigit(*token)) {
                    repetition = repetition * 10 + (*token - '0');
                }
                token++;
            }
        } else if ((token = strstr(is->text1, "sil:")) != NULL) {
            token += strlen("sil:");
            if (isdigit(*(token + 1))) {
                int char_count = atoi(token + 1);
                char character = *(token + 3);
                deleteCharacter(&head, character, char_count,&node_index);
            }
        } else if (strstr(is->text1, "sonagit:") != NULL) {
             GoToLast(head,&node_index);
            continue;
        } else if (strstr(is->text1, "dur:") != NULL) {
            break;
        }
    }

    // Print the doubly linked list to the output file
    printListToFile(outFile, head);
    fprintf(outFile, "\n");
   
    

    // Close the output file
    fclose(outFile);

    // Free memory allocated for the doubly linked list
    while (head != NULL) {
        struct Node* temp = head;
        head = head->next;
        free(temp);
    }

    // Free the memory allocated for the input struct
    jettison_inputstruct(is);

    return 0;
}