# İstenenler #

## Soyut Kisi sınıfını oluşturunuz ##

    1. Kişisel bilgiler için aşağıdaki alanları oluşturunuz.
       + Ad
       + Soyad
       + Ev Adresi

    2. Bu bilgileri geri döndüren metodu barındırsın.

## Kisi sınıfından Personel ve Musteri sınıflarını türetiniz ##

    1. Müşteri Sınıfı aşağıdaki alanları oluştursun
       + Telefon no
       + İş adresi
    2. Müşteri sınıfı bu bilgileri de geri donduren metodu barındırsın.
    3. Personel sınıfı aşağıdaki alanları kapsasın.
        a) sicil no
        b) bölüm
    4. Personel sınıfıda bu bilgileri geri döndüren metodu barındırsın.

## Adres sınıfında aşağıdaki alanlar olsun ##

    a) il Bilgisi
    b) Adres Bilgisi

### Uygulama sınıfı içerisinde, çok sayıda müşteriye ait bilgiler (adresler dahil) klavyeden alınız (ilgili nesneleri oluşturunuz).Daha sonra, oluşturulan müşterilere ait bilgileri  ekrana yazdırınız ###

### Öncelikle UML Sınıf Şemasını oluşturunuz ###

[EOF]