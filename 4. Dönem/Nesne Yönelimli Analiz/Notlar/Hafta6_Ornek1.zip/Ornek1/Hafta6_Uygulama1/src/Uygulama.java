

public class Uygulama {

    public static void main(String args[]){

        Facade.BilAlVer();
        
    }
}