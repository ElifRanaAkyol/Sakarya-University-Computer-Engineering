import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Facade {

    public static  void BilAlVer()
    {
        List<Musteri> musteriListesi = new ArrayList<>();

        try (Scanner giris = new Scanner(System.in)) {

            System.out.println("**********Müşteri Bilgilerini Giriniz*********");

            String cevap;
            String adi;
            String soyadi;
            String telefonNo;
            String adresSatiri;
            String il;
            Adres evAdresi;
            Adres isAdresi;

            do{
                System.out.print("\nMüşteri adını giriniz:");
                adi=giris.nextLine();
                System.out.print("Müşteri soyadını giriniz:");
                soyadi=giris.nextLine();
                System.out.print("Müşteri telefon numarasını giriniz:");
                telefonNo=giris.nextLine();

                System.out.print("Ev adresi bigilerini giriniz:");
                adresSatiri=giris.nextLine();
                System.out.print("Ev adresinin il bilgilerini giriniz:");
                il=giris.nextLine();
               
                evAdresi=new Adres(adresSatiri,il);

                System.out.print("İş adresi bilgilerini giriniz:");
                adresSatiri=giris.nextLine();
                System.out.print("İş adresinin il bilgilerini giriniz:");
                il=giris.nextLine();

                isAdresi=new Adres(adresSatiri,il);

                musteriListesi.add(new Musteri(adi,soyadi,evAdresi,telefonNo,isAdresi));

                System.out.print("\n\nEklemek istediğiniz kayıt var mı (e/h)?");
                cevap=giris.nextLine();

            }while(cevap.equalsIgnoreCase("E"));

            for(Musteri musteri:musteriListesi)
                System.out.println("\nMüşteri Adı: " + musteri.getAd()+" "+
                                    "Müşteri Soyadı: " +musteri.getSoyad()+" "+ 
                                    "Müşteri Telefon Numarası: " + musteri.getTelefonNo() + " "+
                                    "Müşteri Ev Adresi: " + musteri.getEvAdresi().getAdresSatiri()+" / "+ musteri.getEvAdresi().getIl()+ " "+
                                    "Müşteri İş Adresi: " + musteri.getIsAdresi().getAdresSatiri()+" / "+ musteri.getIsAdresi().getIl());

            //System.out.println("\n" +musteriListesi+"\n");

            //musteriListesi.forEach(item->System.out.println("\n" + item.getEvAdresi().getIl()));
        }
    }
    
}
