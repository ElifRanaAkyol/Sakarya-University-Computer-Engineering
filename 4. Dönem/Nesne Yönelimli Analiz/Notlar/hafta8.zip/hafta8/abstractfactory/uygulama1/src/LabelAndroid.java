package hafta8.abstractfactory.uygulama1.src;

public class LabelAndroid implements ILabel {
    
    public  LabelAndroid(String arg){
        System.out.println("Android labeli oluştu");
    }
    
    @Override
    public void by1() { };
    @Override
    public void by2() { };
}
