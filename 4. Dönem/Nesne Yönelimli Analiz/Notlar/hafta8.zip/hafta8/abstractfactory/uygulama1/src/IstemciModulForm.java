package hafta8.abstractfactory.uygulama1.src;

public class IstemciModulForm {

    private AbstractGUIFactory factory=null;
 

    public IstemciModulForm(AbstractGUIFactory factory) {
        
        this.factory = factory;
    }

    public void Basla(String msg){

        IButon buton1;
        IButon buton2;
        IMetinKutusu mk;
        ILabel label;
        
        System.out.println(msg);
       
        mk=factory.metinKutusuOlustur();
        mk.mky1();
       
        buton1=factory.butonOlustur();
        buton1.by1(); // Example usage of buton1
        buton2=factory.butonOlustur();
        buton2.by2(); // Example usage of buton2   
        label=factory.labelOlustur();     
        label.by1(); // Example usage of label
    }
}
