package hafta8.abstractfactory.uygulama1.src;

class FactoryUbuntu implements AbstractGUIFactory{

    @Override
    public IButon butonOlustur(){
        return new ButonUbuntu("UbuntuButon");
    }
    @Override
    public IMetinKutusu metinKutusuOlustur(){
        return new MetinKutusuUbuntu("UbuntuMetinKutusu");
    }
    @Override
    public ILabel labelOlustur(){
        return new LabelUbuntu("UbuntuLabel");
    }
}
