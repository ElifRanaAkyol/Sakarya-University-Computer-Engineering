package hafta8.abstractfactory.uygulama1.src;

class ButonAndroid implements IButon {
   
    public  ButonAndroid(String arg){
        System.out.println("Android butonu oluştu");
    }
    
    @Override
    public void by1() { };
    @Override
    public void by2() { };
}
