package hafta8.abstractfactory.uygulama1.src;

class ButonUbuntu implements IButon {
    public ButonUbuntu(String arg){
        System.out.println("Ubuntu butonu oluştu");
    }
    
    @Override
    public void by1() { };
    @Override
    public void by2() { };
}
