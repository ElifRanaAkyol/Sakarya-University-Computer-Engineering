package hafta8.abstractfactory.uygulama1.src;

public interface IButon {
    public abstract void by1();
    public abstract void by2();
}
