package hafta8.abstractfactory.uygulama1.src;

public class LabelUbuntu implements ILabel {

    public LabelUbuntu(String arg) {
        System.out.println("Ubuntu labeli oluştu");
    }

   @Override
   public void by1() {}
    @Override
    public void by2() {}
    
}
