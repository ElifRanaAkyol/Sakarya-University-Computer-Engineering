package hafta8.abstractfactory.uygulama1.src;

public class FactoryAndroid implements AbstractGUIFactory {
    @Override
        public IButon butonOlustur(){
        return new ButonAndroid("AndroidButon");
    }
   
    @Override
    public IMetinKutusu metinKutusuOlustur(){
        return new MetinKutusuAndroid("AndroidMetinKutusu");
    }
    @Override
    public ILabel labelOlustur(){
        return new LabelAndroid("AndroidLabel");
    }
}
