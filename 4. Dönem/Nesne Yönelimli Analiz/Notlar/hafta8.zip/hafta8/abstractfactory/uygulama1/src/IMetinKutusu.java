package hafta8.abstractfactory.uygulama1.src;


public interface IMetinKutusu {
    public abstract void mky1();
    public abstract void mky2();
}
