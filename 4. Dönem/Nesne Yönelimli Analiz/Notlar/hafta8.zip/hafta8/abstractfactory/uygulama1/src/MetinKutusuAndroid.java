package hafta8.abstractfactory.uygulama1.src;

public class MetinKutusuAndroid implements IMetinKutusu {
    
    public MetinKutusuAndroid(String arg){
        System.out.println("Android metin kutusu oluştu");
    }
    
    @Override
    public void mky1() { };
    
    @Override
    public  void mky2(){ };
}
