package hafta8.abstractfactory.uygulama1.src;

public interface AbstractGUIFactory{

    public IButon butonOlustur();
    public IMetinKutusu metinKutusuOlustur();
    public ILabel labelOlustur();
    

}
