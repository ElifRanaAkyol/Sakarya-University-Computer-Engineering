package hafta8.abstractfactory.uygulama1.src;

public class MetinKutusuUbuntu implements IMetinKutusu {
    public MetinKutusuUbuntu(String arg){
        System.out.println("Ubuntu metin kutusu oluştu");
    }
    @Override
    public  void mky1(){ };
    @Override
    public  void mky2(){ };
}
