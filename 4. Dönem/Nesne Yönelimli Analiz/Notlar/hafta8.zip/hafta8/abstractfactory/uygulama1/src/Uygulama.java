package hafta8.abstractfactory.uygulama1.src;


public class Uygulama {
    public static void main(String args[]){

        AbstractGUIFactory pf;

        String sistem="ubuntu"; // "android" veya "ubuntu" olabilir
       
        if(sistem.equalsIgnoreCase("ubuntu"))
           pf=new FactoryUbuntu();
       
        else
            pf=new FactoryAndroid();

        IstemciModulForm form=new IstemciModulForm(pf);
       
        form.Basla("Form Oluşturuldu");
    }
}