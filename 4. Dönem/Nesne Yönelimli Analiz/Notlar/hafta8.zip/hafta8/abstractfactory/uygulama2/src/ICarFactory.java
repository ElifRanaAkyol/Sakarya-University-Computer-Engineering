package hafta8.abstractfactory.uygulama2.src;

public interface ICarFactory {
    ICar createCar();
}
