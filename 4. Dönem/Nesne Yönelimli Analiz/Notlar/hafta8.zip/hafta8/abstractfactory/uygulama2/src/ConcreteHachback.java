package hafta8.abstractfactory.uygulama2.src;

public class ConcreteHachback implements ICar {
    @Override
    public void drive() {
        System.out.println("Driving a hatchback car");
    }
}