package hafta8.abstractfactory.uygulama2.src;

public class CarFactoryHachback implements ICarFactory {
    @Override
    public ICar createCar() {
        return new ConcreteHachback();
    }
}