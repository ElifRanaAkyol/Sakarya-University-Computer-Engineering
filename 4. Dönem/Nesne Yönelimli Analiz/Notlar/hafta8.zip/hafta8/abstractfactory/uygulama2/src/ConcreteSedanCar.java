package hafta8.abstractfactory.uygulama2.src;

public class ConcreteSedanCar implements ICar {
    @Override
    public void drive() {
        System.out.println("Driving a sedan car");
    }
}
