package hafta8.abstractfactory.uygulama2.src;

import java.util.Scanner;

public class UserManager {
    
    public int getUserSelection() {
       
        System.out.println("Hangi aracı üretmek istersiniz?");
        System.out.println("1 - Sedan");
        System.out.println("2 - Fastback");
        System.out.println("3 - Hachback");
        System.out.print("Seçiminizi yapın (1/2/3): ");
       
        try (Scanner scanner = new Scanner(System.in)) {     
            return scanner.nextInt();
        }
    
    }
}
