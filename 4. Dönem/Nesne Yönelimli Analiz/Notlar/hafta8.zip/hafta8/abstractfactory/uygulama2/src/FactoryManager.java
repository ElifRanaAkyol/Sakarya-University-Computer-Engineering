package hafta8.abstractfactory.uygulama2.src;


public class FactoryManager {
    
    private ICarFactory factory=null;

    public FactoryManager(ICarFactory factory) {
        this.factory = factory;
    }

    public ICar getCar() {
        return factory.createCar();
    }
}
