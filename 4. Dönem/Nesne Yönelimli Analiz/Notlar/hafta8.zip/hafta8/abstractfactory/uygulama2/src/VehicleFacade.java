package hafta8.abstractfactory.uygulama2.src;


public class VehicleFacade {

    private UserManager userInputManager=null;
    private VehicleFactoryManager vehicleFactoryManager=null;
    private FactoryManager factoryManager = null;
    private ICar car=null;
    private ICarFactory factory=null;
    
    public VehicleFacade() {
        userInputManager = new UserManager();
        vehicleFactoryManager = new VehicleFactoryManager();
    }

    // Kullanıcıdan giriş alınarak doğru aracı üretme işlemi
    public void produceVehicle() {
        int choice = userInputManager.getUserSelection();
        factory = vehicleFactoryManager.getFactory(choice);
        
        if (factory != null) {
            factoryManager = new FactoryManager(factory);
            car= factoryManager.getCar();
            car.drive();
        } else {
            System.out.println("Geçersiz seçim. Lütfen tekrar deneyin.");
        }
    }
}