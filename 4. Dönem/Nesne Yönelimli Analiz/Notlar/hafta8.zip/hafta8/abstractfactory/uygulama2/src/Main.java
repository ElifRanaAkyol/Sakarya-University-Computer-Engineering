package hafta8.abstractfactory.uygulama2.src;

public class Main {
    public static void main(String[] args) {
        // Facade sınıfı aracılığıyla tüm işlemi başlatıyoruz
        VehicleFacade vehicleFacade = new VehicleFacade();
        vehicleFacade.produceVehicle();  // Aracın üretimi ve sürülmesi işlemini başlat
    }
}