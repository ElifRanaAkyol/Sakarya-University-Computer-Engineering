package hafta8.abstractfactory.uygulama2.src;

public interface ICar {
    void drive();
}