package hafta8.abstractfactory.uygulama2.src;

public class CarFactorySedanCar implements ICarFactory {
    @Override
    public ICar createCar() {
        return new ConcreteSedanCar();
    }
}