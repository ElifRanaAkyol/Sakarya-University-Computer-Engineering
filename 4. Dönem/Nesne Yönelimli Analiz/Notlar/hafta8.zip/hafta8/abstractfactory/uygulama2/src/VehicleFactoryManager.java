package hafta8.abstractfactory.uygulama2.src;

public class VehicleFactoryManager {
   
    public ICarFactory getFactory(int choice) {
        return switch (choice) {
            case 1 -> new CarFactorySedanCar();  // Sedan üretmek için fabrika
            case 2 -> new CarFactoyFastback();  // Fastback üretmek için fabrika
            case 3 -> new CarFactoryHachback();  // Hachback üretmek için fabrika
            default -> {
                System.out.println("Geçersiz seçim. Lütfen 1, 2 veya 3 seçin.");
                yield null;
            }
        };
    }
}