package hafta8.abstractfactory.uygulama2.src;

public class ConcreteFastback implements ICar {
    @Override
    public void drive() {
        System.out.println("Driving a fastback car");
    }
}