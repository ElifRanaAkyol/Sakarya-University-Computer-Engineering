package hafta8.abstractfactory.uygulama2.src;

    public class CarFactoyFastback implements ICarFactory {
        @Override
        public ICar createCar() {
            return new ConcreteFastback();
        }
    }

